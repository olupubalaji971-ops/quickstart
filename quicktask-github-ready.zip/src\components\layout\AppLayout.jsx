import React, { useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { Navbar } from './Navbar';
import { Sidebar } from './Sidebar';
import { TaskFormModal } from '../tasks/TaskFormModal';
import { useTasks } from '../../context/TaskContext';

export const AppLayout = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [addTaskModalOpen, setAddTaskModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { addTask } = useTasks();
  const location = useLocation();

  const handleCreateTask = (data) => {
    addTask(data);
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', backgroundColor: 'var(--bg-app)' }}>
      {/* Top Navbar */}
      <Navbar
        onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      <div style={{ display: 'flex', flex: 1 }}>
        {/* Sidebar */}
        <Sidebar
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          onOpenAddTask={() => setAddTaskModalOpen(true)}
        />

        {/* Main Content Area */}
        <main
          style={{
            flex: 1,
            padding: '28px 32px',
            maxWidth: 1300,
            margin: '0 auto',
            width: '100%',
            overflowX: 'hidden'
          }}
          className="main-content-container"
        >
          <Outlet context={{ searchQuery, setSearchQuery, onOpenAddTask: () => setAddTaskModalOpen(true) }} />
        </main>
      </div>

      {/* Global Add Task Modal */}
      <TaskFormModal
        isOpen={addTaskModalOpen}
        onClose={() => setAddTaskModalOpen(false)}
        onSubmit={handleCreateTask}
      />
    </div>
  );
};
