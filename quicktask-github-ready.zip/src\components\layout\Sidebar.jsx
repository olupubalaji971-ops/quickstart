import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useTasks } from '../../context/TaskContext';
import { useAuth } from '../../context/AuthContext';
import {
  LayoutDashboard,
  ListTodo,
  Clock,
  CheckCircle2,
  Settings,
  User,
  PlusCircle,
  LogOut,
  Sparkles
} from 'lucide-react';

export const Sidebar = ({ isOpen, onClose, onOpenAddTask }) => {
  const { stats } = useTasks();
  const { logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const navItems = [
    {
      name: 'Dashboard',
      path: '/dashboard',
      icon: LayoutDashboard
    },
    {
      name: 'All Tasks',
      path: '/tasks',
      icon: ListTodo,
      badge: stats.total
    },
    {
      name: 'Pending',
      path: '/pending',
      icon: Clock,
      badge: stats.pending,
      badgeColor: 'badge-medium'
    },
    {
      name: 'Completed',
      path: '/completed',
      icon: CheckCircle2,
      badge: stats.completed,
      badgeColor: 'badge-completed'
    },
    {
      name: 'Settings',
      path: '/settings',
      icon: Settings
    },
    {
      name: 'Profile',
      path: '/profile',
      icon: User
    }
  ];

  return (
    <>
      {/* Mobile backdrop overlay */}
      {isOpen && (
        <div
          className="sidebar-backdrop"
          onClick={onClose}
          style={{
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(15, 23, 42, 0.4)',
            zIndex: 45
          }}
        />
      )}

      <aside
        className={`app-sidebar ${isOpen ? 'open' : ''}`}
        style={{
          width: 'var(--sidebar-width)',
          backgroundColor: 'var(--bg-card)',
          borderRight: '1px solid var(--border-color)',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          height: 'calc(100vh - var(--navbar-height))',
          position: 'sticky',
          top: 'var(--navbar-height)',
          zIndex: 48,
          transition: 'transform var(--transition-normal), background-color var(--transition-normal)',
          padding: '20px 16px'
        }}
      >
        <div>
          {/* Action button: + New Task */}
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => {
              if (onOpenAddTask) onOpenAddTask();
              if (isOpen && onClose) onClose();
            }}
            style={{
              width: '100%',
              marginBottom: 24,
              padding: '12px 16px',
              fontSize: '0.95rem',
              borderRadius: 'var(--radius-md)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 8
            }}
          >
            <PlusCircle size={20} strokeWidth={2.4} />
            <span>+ Add Task</span>
          </button>

          {/* Navigation Links */}
          <nav style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  onClick={() => isOpen && onClose && onClose()}
                  className={({ isActive }) =>
                    `sidebar-link ${isActive ? 'active' : ''}`
                  }
                  style={({ isActive }) => ({
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '10px 14px',
                    borderRadius: 'var(--radius-md)',
                    fontWeight: isActive ? 600 : 500,
                    fontSize: '0.92rem',
                    color: isActive ? '#FFFFFF' : 'var(--text-muted)',
                    backgroundColor: isActive ? 'var(--color-primary)' : 'transparent',
                    transition: 'all var(--transition-fast)'
                  })}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <Icon size={19} />
                    <span>{item.name}</span>
                  </div>

                  {item.badge !== undefined && (
                    <span
                      style={{
                        padding: '2px 8px',
                        borderRadius: 'var(--radius-full)',
                        fontSize: '0.75rem',
                        fontWeight: 700,
                        backgroundColor: item.badgeColor
                          ? undefined
                          : 'var(--bg-subtle)',
                        color: item.badgeColor ? undefined : 'var(--text-main)'
                      }}
                      className={item.badgeColor || ''}
                    >
                      {item.badge}
                    </span>
                  )}
                </NavLink>
              );
            })}
          </nav>
        </div>

        {/* Bottom card & Logout */}
        <div>
          {/* Quick SaaS Tip / Offline Badge */}
          <div
            style={{
              backgroundColor: 'var(--bg-subtle)',
              border: '1px solid var(--border-color)',
              borderRadius: 'var(--radius-md)',
              padding: '12px 14px',
              marginBottom: 16
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
              <Sparkles size={16} color="var(--color-secondary)" />
              <span style={{ fontWeight: 700, fontSize: '0.82rem', color: 'var(--text-main)' }}>
                QuickTask Pro
              </span>
            </div>
            <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', lineHeight: 1.4 }}>
              LocalStorage synced & 100% offline resilient.
            </p>
          </div>

          <button
            type="button"
            onClick={handleLogout}
            className="btn-ghost"
            style={{
              width: '100%',
              display: 'flex',
              alignItems: 'center',
              gap: 12,
              padding: '10px 14px',
              borderRadius: 'var(--radius-md)',
              fontSize: '0.9rem',
              color: 'var(--color-danger)'
            }}
          >
            <LogOut size={18} />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>
    </>
  );
};
