import React, { useState, useMemo } from 'react';
import { useOutletContext, useLocation } from 'react-router-dom';
import { useTasks } from '../context/TaskContext';
import { FilterBar } from '../components/tasks/FilterBar';
import { TaskTable } from '../components/tasks/TaskTable';
import { ListTodo, Clock, CheckCircle2 } from 'lucide-react';

export const TasksViewPage = ({ defaultStatus = 'All' }) => {
  const { tasks } = useTasks();
  const outletContext = useOutletContext() || {};
  const location = useLocation();

  // Determine view based on pathname if not passed
  let initialStatus = defaultStatus;
  if (location.pathname.includes('/completed')) {
    initialStatus = 'Completed';
  } else if (location.pathname.includes('/pending')) {
    initialStatus = 'Pending';
  }

  const [statusFilter, setStatusFilter] = useState(initialStatus);
  const [priorityFilter, setPriorityFilter] = useState('All');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [localSearch, setLocalSearch] = useState('');

  const activeSearch = outletContext.searchQuery !== undefined ? outletContext.searchQuery : localSearch;
  const setActiveSearch = outletContext.setSearchQuery || setLocalSearch;

  const pageTitle =
    statusFilter === 'Completed'
      ? 'Completed Tasks'
      : statusFilter === 'Pending'
      ? 'Pending Tasks'
      : 'All Tasks';

  const PageIcon =
    statusFilter === 'Completed'
      ? CheckCircle2
      : statusFilter === 'Pending'
      ? Clock
      : ListTodo;

  const filteredTasks = useMemo(() => {
    return tasks.filter((task) => {
      if (statusFilter !== 'All' && task.status !== statusFilter) {
        return false;
      }
      if (priorityFilter !== 'All' && task.priority !== priorityFilter) {
        return false;
      }
      if (categoryFilter !== 'All' && task.category !== categoryFilter) {
        return false;
      }
      if (activeSearch && activeSearch.trim() !== '') {
        const query = activeSearch.toLowerCase().trim();
        const matchTitle = task.title.toLowerCase().includes(query);
        const matchDesc = task.description?.toLowerCase().includes(query) || false;
        const matchCategory = task.category?.toLowerCase().includes(query) || false;
        if (!matchTitle && !matchDesc && !matchCategory) return false;
      }
      return true;
    });
  }, [tasks, statusFilter, priorityFilter, categoryFilter, activeSearch]);

  return (
    <div>
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          marginBottom: 24
        }}
      >
        <div
          style={{
            width: 42,
            height: 42,
            borderRadius: 'var(--radius-md)',
            backgroundColor: 'var(--color-primary)',
            color: 'var(--color-secondary)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          <PageIcon size={22} />
        </div>
        <div>
          <h1 style={{ fontSize: '1.75rem' }}>{pageTitle}</h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>
            {filteredTasks.length} {filteredTasks.length === 1 ? 'task' : 'tasks'} found in this view
          </p>
        </div>
      </div>

      <FilterBar
        statusFilter={statusFilter}
        setStatusFilter={setStatusFilter}
        priorityFilter={priorityFilter}
        setPriorityFilter={setPriorityFilter}
        categoryFilter={categoryFilter}
        setCategoryFilter={setCategoryFilter}
        searchQuery={activeSearch}
        setSearchQuery={setActiveSearch}
        onOpenAddTask={outletContext.onOpenAddTask}
      />

      <TaskTable tasks={filteredTasks} />
    </div>
  );
};
