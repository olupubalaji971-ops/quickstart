import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { useTasks } from '../context/TaskContext';
import { Input } from '../components/common/Input';
import { Button } from '../components/common/Button';
import { User, Mail, Briefcase, Calendar, Save, CheckCircle2, Award } from 'lucide-react';

export const ProfilePage = () => {
  const { currentUser, updateProfile } = useAuth();
  const { showToast } = useToast();
  const { stats } = useTasks();

  const [name, setName] = useState(currentUser?.name || '');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [role, setRole] = useState(currentUser?.role || 'Productivity Enthusiast');
  const [avatar, setAvatar] = useState(
    currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=256'
  );
  const [isEditing, setIsEditing] = useState(false);
  const [errors, setErrors] = useState({});

  const presetAvatars = [
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=256',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=256',
    'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=256',
    'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=256'
  ];

  const handleSave = (e) => {
    e.preventDefault();
    const newErrors = {};
    if (!name.trim()) newErrors.name = 'Full name is required.';
    if (!email.trim()) newErrors.email = 'Email address is required.';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    updateProfile({
      name: name.trim(),
      email: email.trim(),
      role: role.trim(),
      avatar
    });

    setIsEditing(false);
    showToast('Profile updated successfully!', 'success');
  };

  return (
    <div style={{ maxWidth: 840, margin: '0 auto' }}>
      <div style={{ marginBottom: 28 }}>
        <h1 style={{ fontSize: '1.85rem', marginBottom: 6 }}>My Profile</h1>
        <p style={{ color: 'var(--text-muted)' }}>Manage your personal details and account settings.</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 24 }} className="profile-grid">
        {/* Left: Avatar & Identity Card */}
        <div className="card" style={{ padding: 24, textAlign: 'center' }}>
          <div
            style={{
              width: 100,
              height: 100,
              borderRadius: '50%',
              margin: '0 auto 16px',
              overflow: 'hidden',
              border: '3px solid var(--color-secondary)',
              boxShadow: 'var(--shadow-md)'
            }}
          >
            <img
              src={avatar}
              alt={currentUser?.name}
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
            />
          </div>

          <h3 style={{ fontSize: '1.25rem', marginBottom: 4 }}>{currentUser?.name}</h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem', marginBottom: 16 }}>
            {currentUser?.email}
          </p>

          <span className="badge badge-medium" style={{ marginBottom: 20 }}>
            {currentUser?.role || 'Member'}
          </span>

          {isEditing && (
            <div style={{ marginTop: 16, textAlign: 'left' }}>
              <label className="form-label" style={{ fontSize: '0.8rem' }}>
                Select Avatar:
              </label>
              <div style={{ display: 'flex', gap: 8, justifyContent: 'center', marginTop: 8 }}>
                {presetAvatars.map((url, i) => (
                  <img
                    key={i}
                    src={url}
                    alt={`Avatar ${i + 1}`}
                    onClick={() => setAvatar(url)}
                    style={{
                      width: 42,
                      height: 42,
                      borderRadius: '50%',
                      cursor: 'pointer',
                      border: avatar === url ? '3px solid var(--color-secondary)' : '1px solid var(--border-color)',
                      objectFit: 'cover'
                    }}
                  />
                ))}
              </div>
            </div>
          )}

          <div
            style={{
              marginTop: 24,
              paddingTop: 18,
              borderTop: '1px solid var(--border-color)',
              display: 'flex',
              flexDirection: 'column',
              gap: 10,
              textAlign: 'left',
              fontSize: '0.85rem',
              color: 'var(--text-muted)'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <CheckCircle2 size={16} color="var(--color-success)" />
              <span>{stats.completed} Tasks Completed</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <Award size={16} color="var(--color-secondary)" />
              <span>QuickTask Verified User</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <Calendar size={16} />
              <span>Member since {currentUser?.joinedDate || 'Jan 2026'}</span>
            </div>
          </div>
        </div>

        {/* Right: Profile Details & Edit Form */}
        <div className="card" style={{ padding: 28 }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginBottom: 20,
              paddingBottom: 12,
              borderBottom: '1px solid var(--border-color)'
            }}
          >
            <h3 style={{ fontSize: '1.2rem' }}>Account Information</h3>
            <Button
              variant={isEditing ? 'ghost' : 'outline'}
              size="sm"
              onClick={() => setIsEditing(!isEditing)}
            >
              {isEditing ? 'Cancel' : 'Edit Profile'}
            </Button>
          </div>

          <form onSubmit={handleSave}>
            <Input
              label="Full Name"
              name="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              icon={User}
              disabled={!isEditing}
              error={errors.name}
              required
            />

            <Input
              label="Email Address"
              name="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              icon={Mail}
              disabled={!isEditing}
              error={errors.email}
              required
            />

            <Input
              label="Job Role / Title"
              name="role"
              value={role}
              onChange={(e) => setRole(e.target.value)}
              icon={Briefcase}
              disabled={!isEditing}
              placeholder="e.g. Lead Engineer, Student"
            />

            {isEditing && (
              <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 12 }}>
                <Button variant="secondary" type="submit" icon={Save}>
                  Save Profile Changes
                </Button>
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
};
