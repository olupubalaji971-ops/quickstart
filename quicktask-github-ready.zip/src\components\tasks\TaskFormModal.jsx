import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { Input } from '../common/Input';
import { Button } from '../common/Button';
import { CATEGORIES } from '../../utils/initialData';
import { Calendar, Tag, AlertCircle } from 'lucide-react';

export const TaskFormModal = ({ isOpen, onClose, onSubmit, initialTask = null }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState('Medium');
  const [dueDate, setDueDate] = useState('');
  const [category, setCategory] = useState('Work');
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (initialTask) {
      setTitle(initialTask.title || '');
      setDescription(initialTask.description || '');
      setPriority(initialTask.priority || 'Medium');
      setDueDate(initialTask.dueDate || new Date().toISOString().split('T')[0]);
      setCategory(initialTask.category || 'Work');
    } else {
      setTitle('');
      setDescription('');
      setPriority('Medium');
      setDueDate(new Date().toISOString().split('T')[0]);
      setCategory('Work');
    }
    setErrors({});
  }, [initialTask, isOpen]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const newErrors = {};

    if (!title.trim()) {
      newErrors.title = 'Task title is required.';
    } else if (title.trim().length < 3) {
      newErrors.title = 'Task title should be at least 3 characters.';
    }

    if (!dueDate) {
      newErrors.dueDate = 'Please select a due date.';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    onSubmit({
      title: title.trim(),
      description: description.trim(),
      priority,
      dueDate,
      category
    });

    onClose();
  };

  const availableCategories = CATEGORIES.filter((c) => c !== 'All');

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={initialTask ? 'Edit Task' : 'Add New Task'}
      maxWidth={520}
    >
      <form onSubmit={handleSubmit}>
        <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* Task Title */}
          <Input
            label="Task Title"
            name="title"
            value={title}
            onChange={(e) => {
              setTitle(e.target.value);
              if (errors.title) setErrors((prev) => ({ ...prev, title: null }));
            }}
            placeholder="e.g. Complete assignment, Submit project"
            error={errors.title}
            required
            autoFocus
          />

          {/* Description */}
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label" htmlFor="task-description">
              Description (Optional)
            </label>
            <textarea
              id="task-description"
              className="form-textarea"
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add extra context, checklists, or reference links..."
            />
          </div>

          {/* Priority & Category in grid */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 16 }}>
            {/* Priority Picker */}
            <div className="form-group" style={{ marginBottom: 0 }}>
              <label className="form-label">Priority</label>
              <div style={{ display: 'flex', gap: 8 }}>
                {['Low', 'Medium', 'High'].map((p) => {
                  const isSelected = priority === p;
                  let activeBorder = 'var(--color-primary)';
                  let activeBg = 'var(--color-primary)';
                  let activeColor = '#FFFFFF';

                  if (p === 'High') {
                    activeBorder = 'var(--color-danger)';
                    activeBg = 'var(--color-danger)';
                  } else if (p === 'Medium') {
                    activeBorder = 'var(--color-secondary)';
                    activeBg = 'var(--color-secondary)';
                    activeColor = '#0F172A';
                  } else if (p === 'Low') {
                    activeBorder = 'var(--color-info)';
                    activeBg = 'var(--color-info)';
                  }

                  return (
                    <button
                      key={p}
                      type="button"
                      onClick={() => setPriority(p)}
                      style={{
                        flex: 1,
                        padding: '8px 10px',
                        borderRadius: 'var(--radius-md)',
                        fontSize: '0.85rem',
                        fontWeight: 600,
                        border: `1.5px solid ${isSelected ? activeBorder : 'var(--border-color)'}`,
                        backgroundColor: isSelected ? activeBg : 'var(--bg-subtle)',
                        color: isSelected ? activeColor : 'var(--text-muted)',
                        transition: 'all var(--transition-fast)'
                      }}
                    >
                      {p}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Category Dropdown */}
            <div className="form-group" style={{ marginBottom: 0 }}>
              <label className="form-label" htmlFor="task-category">
                Category
              </label>
              <select
                id="task-category"
                className="form-select"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
              >
                {availableCategories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Due Date */}
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label" htmlFor="task-due-date">
              Due Date <span style={{ color: 'var(--color-danger)' }}>*</span>
            </label>
            <div style={{ position: 'relative' }}>
              <input
                type="date"
                id="task-due-date"
                className="form-input"
                value={dueDate}
                onChange={(e) => {
                  setDueDate(e.target.value);
                  if (errors.dueDate) setErrors((prev) => ({ ...prev, dueDate: null }));
                }}
              />
            </div>
            {errors.dueDate && (
              <div className="form-error">
                <AlertCircle size={14} />
                <span>{errors.dueDate}</span>
              </div>
            )}
          </div>
        </div>

        <div className="modal-footer">
          <Button variant="outline" onClick={onClose} type="button">
            Cancel
          </Button>
          <Button variant="secondary" type="submit">
            {initialTask ? 'Save Changes' : 'Add Task'}
          </Button>
        </div>
      </form>
    </Modal>
  );
};
