import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { Logo } from '../components/common/Logo';
import { Input } from '../components/common/Input';
import { Button } from '../components/common/Button';
import { Mail, Lock, KeyRound, Sparkles, ArrowRight } from 'lucide-react';
import '../styles/auth.css';

export const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const { login } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const validate = () => {
    const newErrors = {};

    if (!email.trim()) {
      newErrors.email = 'Email address is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      newErrors.email = 'Please enter a valid email address.';
    }

    if (!password) {
      newErrors.password = 'Password is required.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    setLoading(true);

    setTimeout(() => {
      const result = login(email, password, rememberMe);
      setLoading(false);

      if (result.success) {
        showToast(`Welcome back, ${result.user.name}!`, 'success');
        navigate('/dashboard');
      } else {
        setErrors({ general: result.message });
        showToast(result.message, 'error');
      }
    }, 400);
  };

  const handleFillDemo = () => {
    setEmail('test@example.com');
    setPassword('password123');
    setErrors({});
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-card">
        <div className="auth-header">
          <div style={{ display: 'flex', justifyContent: 'center' }}>
            <Logo to="/" size="large" />
          </div>
          <h2 className="auth-title">Welcome Back</h2>
          <p className="auth-subtitle">Sign in to manage your tasks and stay productive.</p>
        </div>

        {/* Quick Demo Credentials Autofill Banner */}
        <div className="demo-credentials-box">
          <div>
            <span style={{ fontWeight: 600, color: 'var(--text-main)', display: 'block' }}>
              Test Credentials:
            </span>
            <span style={{ color: 'var(--text-muted)' }}>test@example.com / password123</span>
          </div>
          <button
            type="button"
            onClick={handleFillDemo}
            className="btn btn-outline btn-sm"
            style={{ fontSize: '0.75rem', padding: '4px 8px' }}
          >
            Auto-Fill
          </button>
        </div>

        {errors.general && (
          <div
            style={{
              padding: '10px 14px',
              borderRadius: 'var(--radius-md)',
              backgroundColor: 'var(--color-danger-bg)',
              color: 'var(--color-danger-text)',
              fontSize: '0.85rem',
              marginBottom: 16
            }}
          >
            {errors.general}
          </div>
        )}

        <form onSubmit={handleSubmit} noValidate>
          <Input
            label="Email Address"
            type="email"
            name="email"
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
              if (errors.email) setErrors((prev) => ({ ...prev, email: null }));
            }}
            placeholder="you@example.com"
            icon={Mail}
            error={errors.email}
            required
            autoComplete="email"
          />

          <Input
            label="Password"
            type="password"
            name="password"
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
              if (errors.password) setErrors((prev) => ({ ...prev, password: null }));
            }}
            placeholder="Enter your password"
            icon={Lock}
            error={errors.password}
            required
            autoComplete="current-password"
          />

          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginBottom: 20,
              fontSize: '0.85rem'
            }}
          >
            <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                style={{ accentColor: 'var(--color-secondary)' }}
              />
              <span style={{ color: 'var(--text-muted)' }}>Remember me</span>
            </label>

            <a
              href="#forgot"
              onClick={(e) => {
                e.preventDefault();
                showToast('Password reset link sent to demo inbox.', 'info');
              }}
              style={{ color: 'var(--color-secondary)', fontWeight: 600 }}
            >
              Forgot Password?
            </a>
          </div>

          <Button
            type="submit"
            variant="primary"
            loading={loading}
            iconRight={ArrowRight}
            style={{ width: '100%', padding: '12px' }}
          >
            Login to QuickTask
          </Button>
        </form>

        <div className="auth-footer">
          Don't have an account?{' '}
          <Link to="/register" className="auth-link">
            Create Account
          </Link>
        </div>
      </div>
    </div>
  );
};
