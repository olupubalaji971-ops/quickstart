import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { Logo } from '../components/common/Logo';
import { Button } from '../components/common/Button';
import {
  CheckCircle2,
  Circle,
  Plus,
  ArrowRight,
  Search,
  SlidersHorizontal,
  FolderKanban,
  Zap,
  ShieldCheck,
  Sun,
  Moon,
  Sparkles
} from 'lucide-react';
import '../styles/landing.css';

export const LandingPage = () => {
  const { isAuthenticated } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();

  // Interactive sample task states in hero mockup
  const [sampleTasks, setSampleTasks] = useState([
    { id: 1, title: 'Complete assignment', priority: 'High', status: 'Pending', tag: 'Study' },
    { id: 2, title: 'Read VLSI notes', priority: 'Medium', status: 'Completed', tag: 'Study' },
    { id: 3, title: 'Submit project report', priority: 'High', status: 'Pending', tag: 'Work' }
  ]);

  const toggleSampleTask = (id) => {
    setSampleTasks((prev) =>
      prev.map((t) =>
        t.id === id
          ? { ...t, status: t.status === 'Completed' ? 'Pending' : 'Completed' }
          : t
      )
    );
  };

  const handleGetStarted = () => {
    if (isAuthenticated) {
      navigate('/dashboard');
    } else {
      navigate('/register');
    }
  };

  const completedCount = sampleTasks.filter((t) => t.status === 'Completed').length;
  const progressPercent = Math.round((completedCount / sampleTasks.length) * 100);

  return (
    <div className="landing-container">
      {/* Header */}
      <header
        style={{
          borderBottom: '1px solid var(--border-color)',
          backgroundColor: 'var(--bg-card)',
          position: 'sticky',
          top: 0,
          zIndex: 50
        }}
      >
        <div className="landing-nav">
          <Logo to="/" />

          <nav className="landing-nav-links">
            <a href="#home" className="landing-nav-link">
              Home
            </a>
            <a href="#features" className="landing-nav-link">
              Features
            </a>
            <a href="#about" className="landing-nav-link">
              About
            </a>
          </nav>

          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <button
              type="button"
              onClick={toggleTheme}
              className="btn-ghost"
              style={{
                width: 38,
                height: 38,
                borderRadius: 'var(--radius-full)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: theme === 'dark' ? 'var(--color-secondary)' : 'var(--text-muted)'
              }}
              title="Toggle theme"
            >
              {theme === 'dark' ? <Sun size={19} /> : <Moon size={19} />}
            </button>

            {isAuthenticated ? (
              <Button variant="primary" onClick={() => navigate('/dashboard')}>
                Go to Dashboard
              </Button>
            ) : (
              <>
                <Link to="/login" className="btn btn-ghost" style={{ fontWeight: 600 }}>
                  Login
                </Link>
                <Button variant="primary" onClick={handleGetStarted}>
                  Get Started
                </Button>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="hero-section">
        <div>
          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 8,
              padding: '6px 14px',
              borderRadius: 'var(--radius-full)',
              backgroundColor: 'var(--color-secondary-light)',
              color: 'var(--color-secondary-text)',
              fontSize: '0.84rem',
              fontWeight: 700,
              marginBottom: 20
            }}
          >
            <Sparkles size={16} />
            <span>Modern Task Management for High Achievers</span>
          </div>

          <h1 className="hero-title">
            Organize Your Day. <br />
            <span style={{ color: 'var(--color-secondary)' }}>Get Things Done.</span>
          </h1>

          <p className="hero-subtitle">
            QuickTask helps you organize, track, and complete your everyday tasks with a simple and powerful dashboard.
          </p>

          <div className="hero-cta-group">
            <Button
              variant="secondary"
              size="lg"
              onClick={handleGetStarted}
              iconRight={ArrowRight}
              style={{ fontWeight: 700 }}
            >
              Get Started Free
            </Button>
            <a href="#features" className="btn btn-outline btn-lg">
              Learn More
            </a>
          </div>

          {/* Quick Credential Hint for testers */}
          <div
            style={{
              marginTop: 24,
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              fontSize: '0.85rem',
              color: 'var(--text-muted)'
            }}
          >
            <ShieldCheck size={16} color="var(--color-success)" />
            <span>Instant Demo Ready • test@example.com / password123</span>
          </div>
        </div>

        {/* Dashboard Mockup Representation Beside Hero */}
        <div>
          <div className="hero-mockup-card">
            <div className="hero-mockup-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: 8,
                    background: 'var(--color-primary)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: 'var(--color-secondary)'
                  }}
                >
                  <Zap size={18} />
                </div>
                <div>
                  <div style={{ fontWeight: 700, fontSize: '0.92rem' }}>QuickTask Live Preview</div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                    Interactive demo preview
                  </div>
                </div>
              </div>
              <span className="badge badge-medium">Active Session</span>
            </div>

            {/* Mock progress bar */}
            <div style={{ marginBottom: 18 }}>
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  fontSize: '0.82rem',
                  fontWeight: 600,
                  marginBottom: 6
                }}
              >
                <span>Today's Progress</span>
                <span style={{ color: 'var(--color-secondary)' }}>{progressPercent}% completed</span>
              </div>
              <div
                style={{
                  height: 8,
                  backgroundColor: 'var(--bg-subtle)',
                  borderRadius: 4,
                  overflow: 'hidden'
                }}
              >
                <div
                  style={{
                    height: '100%',
                    width: `${progressPercent}%`,
                    backgroundColor: 'var(--color-secondary)',
                    transition: 'width 0.3s ease'
                  }}
                />
              </div>
            </div>

            {/* Interactive Mock Tasks */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {sampleTasks.map((t) => {
                const isCompleted = t.status === 'Completed';
                return (
                  <div
                    key={t.id}
                    onClick={() => toggleSampleTask(t.id)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: '12px 14px',
                      borderRadius: 'var(--radius-md)',
                      backgroundColor: 'var(--bg-app)',
                      border: '1px solid var(--border-color)',
                      cursor: 'pointer',
                      transition: 'all var(--transition-fast)'
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                      <div
                        style={{
                          color: isCompleted ? 'var(--color-success)' : 'var(--text-subtle)',
                          display: 'flex'
                        }}
                      >
                        {isCompleted ? <CheckCircle2 size={20} /> : <Circle size={20} />}
                      </div>
                      <div>
                        <div
                          style={{
                            fontSize: '0.9rem',
                            fontWeight: 600,
                            textDecoration: isCompleted ? 'line-through' : 'none',
                            color: isCompleted ? 'var(--text-muted)' : 'var(--text-main)'
                          }}
                        >
                          {t.title}
                        </div>
                        <span style={{ fontSize: '0.75rem', color: 'var(--text-subtle)' }}>
                          {t.tag}
                        </span>
                      </div>
                    </div>
                    <span className={`badge ${t.priority === 'High' ? 'badge-high' : 'badge-medium'}`}>
                      {t.priority}
                    </span>
                  </div>
                );
              })}
            </div>

            <div
              style={{
                marginTop: 18,
                paddingTop: 12,
                borderTop: '1px solid var(--border-color)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between'
              }}
            >
              <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                Click tasks to toggle status!
              </span>
              <Button
                variant="primary"
                size="sm"
                onClick={() => navigate('/dashboard')}
                icon={Plus}
              >
                Launch Dashboard
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="features-section">
        <div className="section-header">
          <span className="section-badge">Built For Performance</span>
          <h2 className="section-title">Everything you need to stay in flow</h2>
          <p className="section-subtitle">
            QuickTask provides purposeful tools that make planning, tracking, and completing your responsibilities seamless.
          </p>
        </div>

        <div className="features-grid">
          {/* Feature 1 */}
          <div className="feature-card">
            <div className="feature-icon-wrapper">
              <Plus size={24} />
            </div>
            <h3 style={{ fontSize: '1.2rem', marginBottom: 8 }}>1. Add Tasks</h3>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.92rem', lineHeight: 1.5 }}>
              Quickly create and organize your tasks with priorities, custom categories, descriptions, and specific due dates.
            </p>
          </div>

          {/* Feature 2 */}
          <div className="feature-card">
            <div className="feature-icon-wrapper">
              <CheckCircle2 size={24} />
            </div>
            <h3 style={{ fontSize: '1.2rem', marginBottom: 8 }}>2. Track Progress</h3>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.92rem', lineHeight: 1.5 }}>
              See what is completed and what still needs attention with dynamic real-time statistics cards and visual indicators.
            </p>
          </div>

          {/* Feature 3 */}
          <div className="feature-card">
            <div className="feature-icon-wrapper">
              <Search size={24} />
            </div>
            <h3 style={{ fontSize: '1.2rem', marginBottom: 8 }}>3. Search & Filter</h3>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.92rem', lineHeight: 1.5 }}>
              Find your tasks instantly using instant keyword search, combined priority dropdowns, and status tabs.
            </p>
          </div>

          {/* Feature 4 */}
          <div className="feature-card">
            <div className="feature-icon-wrapper">
              <FolderKanban size={24} />
            </div>
            <h3 style={{ fontSize: '1.2rem', marginBottom: 8 }}>4. Stay Organized</h3>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.92rem', lineHeight: 1.5 }}>
              Keep your daily work structured in one place. Your data persists safely across browser sessions with zero setup.
            </p>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" style={{ padding: '80px 40px', maxWidth: 1000, margin: '0 auto', textAlign: 'center' }}>
        <h2 style={{ fontSize: '2rem', marginBottom: 14 }}>Designed For Simplicity, Built To Last</h2>
        <p style={{ color: 'var(--text-muted)', fontSize: '1.05rem', lineHeight: 1.6, maxWidth: 680, margin: '0 auto 30px' }}>
          No complicated boards or confusing sub-menus. QuickTask focuses on the core rhythm of getting work done: clarity, speed, and peace of mind.
        </p>
        <Button variant="secondary" size="lg" onClick={handleGetStarted} iconRight={ArrowRight}>
          Try QuickTask Now
        </Button>
      </section>

      {/* Footer */}
      <footer style={{ backgroundColor: 'var(--bg-card)', borderTop: '1px solid var(--border-color)', marginTop: 'auto' }}>
        <div className="landing-footer">
          <Logo to="/" showTagline={true} />
          <div>
            &copy; {new Date().getFullYear()} QuickTask Inc. All rights reserved.
          </div>
          <div style={{ display: 'flex', gap: 20 }}>
            <Link to="/login" style={{ color: 'var(--text-muted)' }}>Login</Link>
            <Link to="/register" style={{ color: 'var(--text-muted)' }}>Register</Link>
            <Link to="/dashboard" style={{ color: 'var(--text-muted)' }}>Dashboard</Link>
          </div>
        </div>
      </footer>
    </div>
  );
};
