// Initial seed tasks and default user data
export const INITIAL_USER = {
  id: 'usr_default_01',
  name: 'Alex Morgan',
  email: 'test@example.com',
  password: 'password123',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=256',
  role: 'Product Designer',
  joinedDate: '2026-01-15'
};

export const INITIAL_TASKS = [
  {
    id: 'task-1',
    title: 'Complete assignment',
    description: 'Finalize and submit the digital electronics research paper before deadline.',
    priority: 'High',
    status: 'Pending',
    dueDate: '2026-09-15',
    category: 'Study',
    createdAt: '2026-09-10T09:00:00.000Z',
    completedAt: null
  },
  {
    id: 'task-2',
    title: 'Read VLSI notes',
    description: 'Review CMOS inverter propagation delay and layout design rules.',
    priority: 'Medium',
    status: 'Completed',
    dueDate: '2026-09-12',
    category: 'Study',
    createdAt: '2026-09-08T14:30:00.000Z',
    completedAt: '2026-09-12T16:20:00.000Z'
  },
  {
    id: 'task-3',
    title: 'Submit project',
    description: 'Upload source code repository, documentation PDF, and live demo link to portal.',
    priority: 'High',
    status: 'Pending',
    dueDate: '2026-09-18',
    category: 'Work',
    createdAt: '2026-09-11T11:15:00.000Z',
    completedAt: null
  },
  {
    id: 'task-4',
    title: 'Prepare presentation',
    description: 'Create slide deck for Monday morning executive sync meeting.',
    priority: 'Low',
    status: 'Pending',
    dueDate: '2026-09-21',
    category: 'Work',
    createdAt: '2026-09-12T10:00:00.000Z',
    completedAt: null
  },
  {
    id: 'task-5',
    title: 'System architecture review',
    description: 'Examine API latency bottlenecks and plan Redis caching layer.',
    priority: 'High',
    status: 'Pending',
    dueDate: '2026-09-16',
    category: 'Work',
    createdAt: '2026-09-12T15:45:00.000Z',
    completedAt: null
  },
  {
    id: 'task-6',
    title: 'Schedule dentist appointment',
    description: 'Call dental clinic for routine six-month checkup and cleaning.',
    priority: 'Low',
    status: 'Completed',
    dueDate: '2026-09-10',
    category: 'Personal',
    createdAt: '2026-09-05T08:00:00.000Z',
    completedAt: '2026-09-10T11:00:00.000Z'
  }
];

export const CATEGORIES = ['All', 'Work', 'Study', 'Personal', 'Finance', 'Health'];
export const PRIORITIES = ['All', 'High', 'Medium', 'Low'];
export const STATUSES = ['All', 'Pending', 'Completed'];
