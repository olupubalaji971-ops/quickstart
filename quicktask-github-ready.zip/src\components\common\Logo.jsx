import React from 'react';
import { CheckSquare } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Logo = ({ to = '/', size = 'normal', showTagline = false }) => {
  return (
    <Link to={to} className="brand-logo" style={{ textDecoration: 'none' }}>
      <div className="brand-icon" style={size === 'large' ? { width: 44, height: 44 } : {}}>
        <CheckSquare size={size === 'large' ? 24 : 20} strokeWidth={2.6} />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        <span className="brand-name" style={size === 'large' ? { fontSize: '1.45rem' } : {}}>
          Quick<span className="brand-highlight">Task</span>
        </span>
        {showTagline && (
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontWeight: 500, marginTop: -2 }}>
            Organize your day, one task at a time.
          </span>
        )}
      </div>
    </Link>
  );
};
