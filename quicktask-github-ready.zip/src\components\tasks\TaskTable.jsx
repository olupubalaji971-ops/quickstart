import React, { useState } from 'react';
import { useTasks } from '../../context/TaskContext';
import { ConfirmDialog } from '../common/ConfirmDialog';
import { TaskFormModal } from './TaskFormModal';
import {
  CheckCircle2,
  Circle,
  Calendar,
  Pencil,
  Trash2,
  Tag,
  Inbox,
  Clock,
  RotateCcw
} from 'lucide-react';

export const TaskTable = ({ tasks }) => {
  const { toggleComplete, deleteTask, updateTask } = useTasks();

  const [taskToEdit, setTaskToEdit] = useState(null);
  const [taskToDelete, setTaskToDelete] = useState(null);

  const formatDueDate = (dateStr) => {
    if (!dateStr) return 'No date';
    try {
      const date = new Date(dateStr + 'T00:00:00');
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const diffTime = date.getTime() - today.getTime();
      const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));

      if (diffDays === 0) return 'Today';
      if (diffDays === 1) return 'Tomorrow';
      if (diffDays === -1) return 'Yesterday';
      if (diffDays < -1) return `${Math.abs(diffDays)}d overdue`;

      return date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: date.getFullYear() !== today.getFullYear() ? 'numeric' : undefined
      });
    } catch {
      return dateStr;
    }
  };

  if (!tasks.length) {
    return (
      <div
        className="card"
        style={{
          padding: '48px 24px',
          textAlign: 'center',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 14
        }}
      >
        <div
          style={{
            width: 56,
            height: 56,
            borderRadius: '50%',
            backgroundColor: 'var(--bg-subtle)',
            color: 'var(--text-subtle)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          <Inbox size={28} />
        </div>
        <div>
          <h4 style={{ fontSize: '1.1rem', marginBottom: 4, color: 'var(--text-main)' }}>
            No tasks found
          </h4>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', maxWidth: 360, margin: '0 auto' }}>
            Try changing your search keywords or adjusting your priority and status filters.
          </p>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* Desktop & Tablet Table Container */}
      <div className="card task-table-card" style={{ overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto' }}>
          <table
            style={{
              width: '100%',
              borderCollapse: 'collapse',
              textAlign: 'left'
            }}
          >
            <thead>
              <tr
                style={{
                  backgroundColor: 'var(--bg-subtle)',
                  borderBottom: '1px solid var(--border-color)',
                  color: 'var(--text-muted)',
                  fontSize: '0.8rem',
                  textTransform: 'uppercase',
                  letterSpacing: '0.05em'
                }}
              >
                <th style={{ padding: '14px 20px', width: 44 }}>Done</th>
                <th style={{ padding: '14px 16px' }}>Task</th>
                <th style={{ padding: '14px 16px', width: 140 }}>Priority</th>
                <th style={{ padding: '14px 16px', width: 150 }}>Due Date</th>
                <th style={{ padding: '14px 16px', width: 130 }}>Status</th>
                <th style={{ padding: '14px 20px', width: 120, textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {tasks.map((task) => {
                const isCompleted = task.status === 'Completed';

                let priorityClass = 'badge-medium';
                if (task.priority === 'High') priorityClass = 'badge-high';
                if (task.priority === 'Low') priorityClass = 'badge-low';

                return (
                  <tr
                    key={task.id}
                    style={{
                      borderBottom: '1px solid var(--border-color)',
                      transition: 'background-color var(--transition-fast)',
                      backgroundColor: isCompleted ? 'rgba(16, 185, 129, 0.02)' : 'transparent'
                    }}
                    className="task-table-row"
                  >
                    {/* Quick Complete Button / Checkbox */}
                    <td style={{ padding: '16px 20px', verticalAlign: 'top' }}>
                      <button
                        type="button"
                        onClick={() => toggleComplete(task.id)}
                        style={{
                          background: 'none',
                          border: 'none',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          color: isCompleted ? 'var(--color-success)' : 'var(--text-subtle)',
                          transition: 'transform var(--transition-fast), color var(--transition-fast)'
                        }}
                        title={isCompleted ? 'Mark as Pending' : 'Mark as Complete'}
                        aria-label={isCompleted ? 'Mark as Pending' : 'Mark as Complete'}
                      >
                        {isCompleted ? (
                          <CheckCircle2 size={22} strokeWidth={2.4} />
                        ) : (
                          <Circle size={22} strokeWidth={2} />
                        )}
                      </button>
                    </td>

                    {/* Task Title, Category & Description */}
                    <td style={{ padding: '16px 16px', verticalAlign: 'top' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                        <span
                          style={{
                            fontWeight: 600,
                            fontSize: '0.95rem',
                            color: isCompleted ? 'var(--text-muted)' : 'var(--text-main)',
                            textDecoration: isCompleted ? 'line-through' : 'none'
                          }}
                        >
                          {task.title}
                        </span>
                        {task.category && (
                          <span className="badge badge-category">
                            {task.category}
                          </span>
                        )}
                      </div>

                      {task.description && (
                        <p
                          style={{
                            fontSize: '0.84rem',
                            color: isCompleted ? 'var(--text-subtle)' : 'var(--text-muted)',
                            marginTop: 4,
                            lineHeight: 1.4,
                            maxWidth: 480
                          }}
                        >
                          {task.description}
                        </p>
                      )}
                    </td>

                    {/* Priority Badge */}
                    <td style={{ padding: '16px 16px', verticalAlign: 'top' }}>
                      <span className={`badge ${priorityClass}`}>{task.priority}</span>
                    </td>

                    {/* Due Date */}
                    <td style={{ padding: '16px 16px', verticalAlign: 'top', whiteSpace: 'nowrap' }}>
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: 6,
                          fontSize: '0.86rem',
                          color: task.dueDate.includes('overdue')
                            ? 'var(--color-danger)'
                            : 'var(--text-muted)'
                        }}
                      >
                        <Calendar size={15} />
                        <span>{formatDueDate(task.dueDate)}</span>
                      </div>
                    </td>

                    {/* Status Badge */}
                    <td style={{ padding: '16px 16px', verticalAlign: 'top' }}>
                      <span
                        className={`badge ${
                          isCompleted ? 'badge-completed' : 'badge-pending'
                        }`}
                      >
                        {task.status}
                      </span>
                    </td>

                    {/* Action Buttons */}
                    <td style={{ padding: '16px 20px', verticalAlign: 'top', textAlign: 'right' }}>
                      <div
                        style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: 6,
                          justifyContent: 'flex-end'
                        }}
                      >
                        {/* Toggle Complete button */}
                        <button
                          type="button"
                          onClick={() => toggleComplete(task.id)}
                          className="btn-ghost btn-sm"
                          style={{
                            padding: 6,
                            color: isCompleted ? 'var(--color-warning)' : 'var(--color-success)'
                          }}
                          title={isCompleted ? 'Reopen task' : 'Complete task'}
                        >
                          {isCompleted ? <RotateCcw size={16} /> : <CheckCircle2 size={16} />}
                        </button>

                        {/* Edit Button */}
                        <button
                          type="button"
                          onClick={() => setTaskToEdit(task)}
                          className="btn-ghost btn-sm"
                          style={{ padding: 6, color: 'var(--text-muted)' }}
                          title="Edit task"
                        >
                          <Pencil size={16} />
                        </button>

                        {/* Delete Button */}
                        <button
                          type="button"
                          onClick={() => setTaskToDelete(task)}
                          className="btn-ghost btn-sm"
                          style={{ padding: 6, color: 'var(--color-danger)' }}
                          title="Delete task"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Task Modal */}
      {taskToEdit && (
        <TaskFormModal
          isOpen={!!taskToEdit}
          onClose={() => setTaskToEdit(null)}
          onSubmit={(data) => updateTask(taskToEdit.id, data)}
          initialTask={taskToEdit}
        />
      )}

      {/* Delete Confirmation Dialog */}
      {taskToDelete && (
        <ConfirmDialog
          isOpen={!!taskToDelete}
          onClose={() => setTaskToDelete(null)}
          onConfirm={() => deleteTask(taskToDelete.id)}
          title="Delete Task"
          message={`Are you sure you want to delete "${taskToDelete.title}"? This action cannot be undone.`}
          confirmText="Delete"
          cancelText="Cancel"
          isDanger={true}
        />
      )}
    </>
  );
};
