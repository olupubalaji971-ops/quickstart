import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { useToast } from '../context/ToastContext';
import { useTasks } from '../context/TaskContext';
import { Button } from '../components/common/Button';
import {
  Moon,
  Sun,
  Bell,
  Mail,
  Volume2,
  Shield,
  Trash2,
  LogOut,
  Sparkles,
  Download,
  RotateCcw
} from 'lucide-react';

export const SettingsPage = () => {
  const { currentUser, preferences, updatePreferences, logout } = useAuth();
  const { theme, toggleTheme, isDark } = useTheme();
  const { showToast } = useToast();
  const { tasks, resetToSampleData } = useTasks();
  const navigate = useNavigate();

  const handleTogglePref = (key) => {
    updatePreferences({ [key]: !preferences[key] });
    showToast('Preference updated.', 'info');
  };

  const handleExportData = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(tasks, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `quicktask_backup_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showToast('Task data exported as JSON.', 'success');
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div style={{ maxWidth: 840, margin: '0 auto' }}>
      <div style={{ marginBottom: 28 }}>
        <h1 style={{ fontSize: '1.85rem', marginBottom: 6 }}>Settings</h1>
        <p style={{ color: 'var(--text-muted)' }}>Customize your application preferences, appearance, and alerts.</p>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
        {/* Section 1: Appearance */}
        <div className="card" style={{ padding: 24 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18 }}>
            <Sun size={20} color="var(--color-secondary)" />
            <h3 style={{ fontSize: '1.2rem' }}>Appearance</h3>
          </div>

          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '16px 0',
              borderTop: '1px solid var(--border-color)'
            }}
          >
            <div>
              <div style={{ fontWeight: 600, fontSize: '0.95rem' }}>Dark Theme</div>
              <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                Switch between high-contrast dark mode and clean light mode.
              </div>
            </div>

            <button
              type="button"
              onClick={toggleTheme}
              style={{
                width: 52,
                height: 28,
                borderRadius: 'var(--radius-full)',
                backgroundColor: isDark ? 'var(--color-secondary)' : 'var(--bg-muted)',
                border: 'none',
                cursor: 'pointer',
                position: 'relative',
                transition: 'background-color var(--transition-fast)'
              }}
              aria-label="Toggle dark mode"
            >
              <div
                style={{
                  width: 22,
                  height: 22,
                  borderRadius: '50%',
                  backgroundColor: '#FFFFFF',
                  position: 'absolute',
                  top: 3,
                  left: isDark ? 27 : 3,
                  transition: 'left var(--transition-fast)',
                  boxShadow: 'var(--shadow-sm)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
              >
                {isDark ? <Moon size={12} color="#0F172A" /> : <Sun size={12} color="#F59E0B" />}
              </div>
            </button>
          </div>
        </div>

        {/* Section 2: Notifications */}
        <div className="card" style={{ padding: 24 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18 }}>
            <Bell size={20} color="var(--color-info)" />
            <h3 style={{ fontSize: '1.2rem' }}>Notifications & Alerts</h3>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '16px 0',
                borderTop: '1px solid var(--border-color)'
              }}
            >
              <div>
                <div style={{ fontWeight: 600, fontSize: '0.95rem' }}>Task Reminders</div>
                <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                  Show badge notifications when tasks are near their due date.
                </div>
              </div>
              <input
                type="checkbox"
                checked={preferences.taskReminders}
                onChange={() => handleTogglePref('taskReminders')}
                style={{ width: 18, height: 18, accentColor: 'var(--color-secondary)' }}
              />
            </div>

            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '16px 0',
                borderTop: '1px solid var(--border-color)'
              }}
            >
              <div>
                <div style={{ fontWeight: 600, fontSize: '0.95rem' }}>Email Digest</div>
                <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                  Receive a weekly summary of completed accomplishments.
                </div>
              </div>
              <input
                type="checkbox"
                checked={preferences.emailNotifications}
                onChange={() => handleTogglePref('emailNotifications')}
                style={{ width: 18, height: 18, accentColor: 'var(--color-secondary)' }}
              />
            </div>

            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '16px 0',
                borderTop: '1px solid var(--border-color)'
              }}
            >
              <div>
                <div style={{ fontWeight: 600, fontSize: '0.95rem' }}>Celebration Confetti</div>
                <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                  Play celebratory confetti particle animations upon completing tasks.
                </div>
              </div>
              <input
                type="checkbox"
                checked={preferences.soundEffects}
                onChange={() => handleTogglePref('soundEffects')}
                style={{ width: 18, height: 18, accentColor: 'var(--color-secondary)' }}
              />
            </div>
          </div>
        </div>

        {/* Section 3: Data Management & Account */}
        <div className="card" style={{ padding: 24 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18 }}>
            <Shield size={20} color="var(--color-success)" />
            <h3 style={{ fontSize: '1.2rem' }}>Data & Backup</h3>
          </div>

          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '16px 0',
              borderTop: '1px solid var(--border-color)',
              flexWrap: 'wrap',
              gap: 12
            }}
          >
            <div>
              <div style={{ fontWeight: 600, fontSize: '0.95rem' }}>Export Tasks</div>
              <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                Download your current tasks in portable JSON format.
              </div>
            </div>
            <Button variant="outline" size="sm" icon={Download} onClick={handleExportData}>
              Export JSON
            </Button>
          </div>

          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '16px 0',
              borderTop: '1px solid var(--border-color)',
              flexWrap: 'wrap',
              gap: 12
            }}
          >
            <div>
              <div style={{ fontWeight: 600, fontSize: '0.95rem' }}>Reset Sample Data</div>
              <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                Restore default tasks and state if needed for testing.
              </div>
            </div>
            <Button variant="outline" size="sm" icon={RotateCcw} onClick={resetToSampleData}>
              Reset Sample Tasks
            </Button>
          </div>

          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '16px 0',
              borderTop: '1px solid var(--border-color)',
              flexWrap: 'wrap',
              gap: 12
            }}
          >
            <div>
              <div style={{ fontWeight: 600, fontSize: '0.95rem', color: 'var(--color-danger)' }}>
                Sign Out
              </div>
              <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                Log out of your current session on this device.
              </div>
            </div>
            <Button variant="danger" size="sm" icon={LogOut} onClick={handleLogout}>
              Logout
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
