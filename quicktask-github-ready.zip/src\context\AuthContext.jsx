import React, { createContext, useContext, useState, useEffect } from 'react';
import { getStoredItem, setStoredItem, removeStoredItem } from '../utils/storage';
import { INITIAL_USER } from '../utils/initialData';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  // Stored users database (mock database)
  const [users, setUsers] = useState(() => {
    return getStoredItem('quicktask_users', [INITIAL_USER]);
  });

  // Current session user
  const [currentUser, setCurrentUser] = useState(() => {
    return getStoredItem('quicktask_current_user', INITIAL_USER);
  });

  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return !!getStoredItem('quicktask_current_user', INITIAL_USER);
  });

  // User preferences (notifications, etc)
  const [preferences, setPreferences] = useState(() => {
    return getStoredItem('quicktask_preferences', {
      emailNotifications: true,
      taskReminders: true,
      soundEffects: true,
      compactView: false
    });
  });

  useEffect(() => {
    setStoredItem('quicktask_users', users);
  }, [users]);

  useEffect(() => {
    if (currentUser) {
      setStoredItem('quicktask_current_user', currentUser);
      setIsAuthenticated(true);
    } else {
      removeStoredItem('quicktask_current_user');
      setIsAuthenticated(false);
    }
  }, [currentUser]);

  useEffect(() => {
    setStoredItem('quicktask_preferences', preferences);
  }, [preferences]);

  // Login handler
  const login = (email, password, remember = true) => {
    const trimmedEmail = email.trim().toLowerCase();
    const foundUser = users.find(
      (u) => u.email.toLowerCase() === trimmedEmail && u.password === password
    );

    if (!foundUser) {
      // Fallback: If user enters test credentials, ensure it works even if cleared
      if (trimmedEmail === 'test@example.com' && password === 'password123') {
        setCurrentUser(INITIAL_USER);
        return { success: true, user: INITIAL_USER };
      }
      return { success: false, message: 'Invalid email or password. Please try again.' };
    }

    setCurrentUser(foundUser);
    return { success: true, user: foundUser };
  };

  // Register handler
  const register = (fullName, email, password) => {
    const trimmedEmail = email.trim().toLowerCase();
    const existing = users.find((u) => u.email.toLowerCase() === trimmedEmail);

    if (existing) {
      return { success: false, message: 'An account with this email already exists.' };
    }

    const newUser = {
      id: 'usr_' + Date.now(),
      name: fullName.trim(),
      email: trimmedEmail,
      password: password,
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(fullName)}`,
      role: 'Productivity Champion',
      joinedDate: new Date().toISOString().split('T')[0]
    };

    setUsers((prev) => [...prev, newUser]);
    setCurrentUser(newUser);
    return { success: true, user: newUser };
  };

  // Update profile
  const updateProfile = (updatedData) => {
    if (!currentUser) return;
    const updated = { ...currentUser, ...updatedData };
    setCurrentUser(updated);
    setUsers((prev) => prev.map((u) => (u.id === updated.id ? updated : u)));
    return updated;
  };

  // Update preferences
  const updatePreferences = (newPrefs) => {
    setPreferences((prev) => ({ ...prev, ...newPrefs }));
  };

  // Logout handler
  const logout = () => {
    setCurrentUser(null);
    setIsAuthenticated(false);
    removeStoredItem('quicktask_current_user');
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isAuthenticated,
        preferences,
        login,
        register,
        logout,
        updateProfile,
        updatePreferences
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
