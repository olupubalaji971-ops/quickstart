import React from 'react';

export const StatsCard = ({ title, count, icon: Icon, color = 'primary', subtitle, onClick }) => {
  let iconBg = 'var(--bg-subtle)';
  let iconColor = 'var(--text-main)';
  let accentBorder = 'transparent';

  if (color === 'success') {
    iconBg = 'var(--color-success-bg)';
    iconColor = 'var(--color-success)';
    accentBorder = 'var(--color-success)';
  } else if (color === 'warning') {
    iconBg = 'var(--color-warning-bg)';
    iconColor = 'var(--color-warning)';
    accentBorder = 'var(--color-warning)';
  } else if (color === 'danger') {
    iconBg = 'var(--color-danger-bg)';
    iconColor = 'var(--color-danger)';
    accentBorder = 'var(--color-danger)';
  } else if (color === 'gold') {
    iconBg = 'var(--color-secondary-light)';
    iconColor = 'var(--color-secondary)';
    accentBorder = 'var(--color-secondary)';
  }

  return (
    <div
      className="card"
      onClick={onClick}
      style={{
        padding: '22px 24px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        cursor: onClick ? 'pointer' : 'default',
        position: 'relative',
        overflow: 'hidden'
      }}
    >
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        <span
          style={{
            fontSize: '0.85rem',
            fontWeight: 600,
            color: 'var(--text-muted)',
            textTransform: 'uppercase',
            letterSpacing: '0.04em'
          }}
        >
          {title}
        </span>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
          <span
            style={{
              fontSize: '2.2rem',
              fontWeight: 800,
              color: 'var(--text-main)',
              lineHeight: 1
            }}
          >
            {count}
          </span>
        </div>
        {subtitle && (
          <span style={{ fontSize: '0.78rem', color: 'var(--text-subtle)', marginTop: 2 }}>
            {subtitle}
          </span>
        )}
      </div>

      <div
        style={{
          width: 52,
          height: 52,
          borderRadius: 'var(--radius-lg)',
          backgroundColor: iconBg,
          color: iconColor,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0
        }}
      >
        <Icon size={26} strokeWidth={2.2} />
      </div>
    </div>
  );
};
