import React, { useState, useMemo } from 'react';
import { useOutletContext } from 'react-router-dom';
import { useTasks } from '../context/TaskContext';
import { useAuth } from '../context/AuthContext';
import { StatsCard } from '../components/tasks/StatsCard';
import { FilterBar } from '../components/tasks/FilterBar';
import { TaskTable } from '../components/tasks/TaskTable';
import {
  ListTodo,
  CheckCircle2,
  Clock,
  AlertTriangle,
  RotateCcw,
  Sparkles
} from 'lucide-react';

export const DashboardPage = () => {
  const { tasks, stats, resetToSampleData } = useTasks();
  const { currentUser } = useAuth();
  const outletContext = useOutletContext() || {};

  // Local filter states
  const [statusFilter, setStatusFilter] = useState('All');
  const [priorityFilter, setPriorityFilter] = useState('All');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [localSearch, setLocalSearch] = useState('');

  // Synchronize with top navbar search if present
  const activeSearch = outletContext.searchQuery !== undefined ? outletContext.searchQuery : localSearch;
  const setActiveSearch = outletContext.setSearchQuery || setLocalSearch;

  // Dynamic greeting based on user's local time
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  const userName = currentUser?.name?.split(' ')[0] || 'User';

  // Filtered tasks computation
  const filteredTasks = useMemo(() => {
    return tasks.filter((task) => {
      // 1. Status Filter
      if (statusFilter !== 'All' && task.status !== statusFilter) {
        return false;
      }

      // 2. Priority Filter
      if (priorityFilter !== 'All' && task.priority !== priorityFilter) {
        return false;
      }

      // 3. Category Filter
      if (categoryFilter !== 'All' && task.category !== categoryFilter) {
        return false;
      }

      // 4. Real-time Search by title, description, and category
      if (activeSearch && activeSearch.trim() !== '') {
        const query = activeSearch.toLowerCase().trim();
        const matchTitle = task.title.toLowerCase().includes(query);
        const matchDesc = task.description?.toLowerCase().includes(query) || false;
        const matchCategory = task.category?.toLowerCase().includes(query) || false;

        if (!matchTitle && !matchDesc && !matchCategory) {
          return false;
        }
      }

      return true;
    });
  }, [tasks, statusFilter, priorityFilter, categoryFilter, activeSearch]);

  return (
    <div>
      {/* Welcome Banner */}
      <div
        style={{
          display: 'flex',
          alignItems: 'flex-start',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: 16,
          marginBottom: 28
        }}
      >
        <div>
          <h1 style={{ fontSize: '1.9rem', marginBottom: 4 }}>
            {getGreeting()}, {userName} 👋
          </h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.98rem' }}>
            Here's what's happening with your tasks today.
          </p>
        </div>

        {/* Quick sample reset tool for testing convenience */}
        <button
          type="button"
          onClick={resetToSampleData}
          className="btn-outline btn-sm"
          style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}
          title="Restore original sample demo tasks"
        >
          <RotateCcw size={14} />
          Reset Demo Tasks
        </button>
      </div>

      {/* 4 Statistics Cards */}
      <div className="stats-grid">
        <StatsCard
          title="Total Tasks"
          count={stats.total}
          icon={ListTodo}
          color="gold"
          subtitle="All tasks in system"
          onClick={() => setStatusFilter('All')}
        />
        <StatsCard
          title="Completed"
          count={stats.completed}
          icon={CheckCircle2}
          color="success"
          subtitle={`${stats.total ? Math.round((stats.completed / stats.total) * 100) : 0}% completion rate`}
          onClick={() => setStatusFilter('Completed')}
        />
        <StatsCard
          title="Pending"
          count={stats.pending}
          icon={Clock}
          color="warning"
          subtitle="Requires attention"
          onClick={() => setStatusFilter('Pending')}
        />
        <StatsCard
          title="High Priority"
          count={stats.highPriority}
          icon={AlertTriangle}
          color="danger"
          subtitle="Urgent action needed"
          onClick={() => {
            setPriorityFilter('High');
            setStatusFilter('Pending');
          }}
        />
      </div>

      {/* Task Section */}
      <div style={{ marginTop: 32 }}>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: 16
          }}
        >
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
            <h2 style={{ fontSize: '1.45rem' }}>My Tasks</h2>
            <span style={{ fontSize: '0.9rem', color: 'var(--text-muted)' }}>
              ({filteredTasks.length} {filteredTasks.length === 1 ? 'task' : 'tasks'})
            </span>
          </div>
        </div>

        {/* Combined Filter & Search Bar */}
        <FilterBar
          statusFilter={statusFilter}
          setStatusFilter={setStatusFilter}
          priorityFilter={priorityFilter}
          setPriorityFilter={setPriorityFilter}
          categoryFilter={categoryFilter}
          setCategoryFilter={setCategoryFilter}
          searchQuery={activeSearch}
          setSearchQuery={setActiveSearch}
          onOpenAddTask={outletContext.onOpenAddTask}
        />

        {/* Task Table / Responsive Cards */}
        <TaskTable tasks={filteredTasks} />
      </div>
    </div>
  );
};
