import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { useTasks } from '../../context/TaskContext';
import { Logo } from '../common/Logo';
import {
  Bell,
  Sun,
  Moon,
  LogOut,
  User,
  Search,
  Menu,
  X,
  CheckCircle2,
  Clock
} from 'lucide-react';

export const Navbar = ({ onToggleSidebar, onSearchChange, searchQuery = '' }) => {
  const { currentUser, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { tasks } = useTasks();
  const navigate = useNavigate();

  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  const pendingCount = tasks.filter((t) => t.status === 'Pending').length;
  const recentTasks = tasks.slice(0, 4);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header
      style={{
        height: 'var(--navbar-height)',
        backgroundColor: 'var(--bg-card)',
        borderBottom: '1px solid var(--border-color)',
        position: 'sticky',
        top: 0,
        zIndex: 40,
        display: 'flex',
        alignItems: 'center',
        padding: '0 20px',
        justifyContent: 'space-between',
        transition: 'background-color var(--transition-normal)'
      }}
    >
      {/* Left side: Mobile menu toggle + Logo */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <button
          type="button"
          className="btn-outline mobile-menu-btn"
          onClick={onToggleSidebar}
          aria-label="Toggle navigation menu"
          style={{
            padding: 8,
            display: 'none',
            borderRadius: 'var(--radius-md)'
          }}
        >
          <Menu size={20} />
        </button>

        <Logo to="/dashboard" />
      </div>

      {/* Middle: Real-time search bar */}
      <div
        style={{
          flex: '0 1 420px',
          margin: '0 20px',
          position: 'relative'
        }}
        className="navbar-search-wrapper"
      >
        <div
          style={{
            position: 'absolute',
            left: 12,
            top: '50%',
            transform: 'translateY(-50%)',
            color: 'var(--text-subtle)',
            display: 'flex',
            alignItems: 'center',
            pointerEvents: 'none'
          }}
        >
          <Search size={16} />
        </div>
        <input
          type="text"
          placeholder="Search tasks by title, category, notes..."
          value={searchQuery}
          onChange={(e) => onSearchChange && onSearchChange(e.target.value)}
          className="form-input"
          style={{
            paddingLeft: 36,
            paddingRight: 12,
            height: 38,
            borderRadius: 'var(--radius-full)',
            backgroundColor: 'var(--bg-subtle)',
            border: '1px solid transparent',
            fontSize: '0.88rem'
          }}
          onFocus={(e) => {
            e.target.style.backgroundColor = 'var(--bg-card)';
            e.target.style.borderColor = 'var(--color-secondary)';
          }}
          onBlur={(e) => {
            e.target.style.backgroundColor = 'var(--bg-subtle)';
            e.target.style.borderColor = 'transparent';
          }}
        />
      </div>

      {/* Right side: Actions, Theme, Notifications, User */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        {/* Dark Mode Toggle */}
        <button
          type="button"
          onClick={toggleTheme}
          className="btn-ghost"
          style={{
            width: 38,
            height: 38,
            borderRadius: 'var(--radius-full)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: theme === 'dark' ? 'var(--color-secondary)' : 'var(--text-muted)'
          }}
          title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          aria-label="Toggle dark mode"
        >
          {theme === 'dark' ? <Sun size={19} /> : <Moon size={19} />}
        </button>

        {/* Notifications Popover */}
        <div style={{ position: 'relative' }}>
          <button
            type="button"
            className="btn-ghost"
            onClick={() => setShowNotifications(!showNotifications)}
            style={{
              width: 38,
              height: 38,
              borderRadius: 'var(--radius-full)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'var(--text-muted)',
              position: 'relative'
            }}
            title="Notifications"
            aria-label="View notifications"
          >
            <Bell size={19} />
            {pendingCount > 0 && (
              <span
                style={{
                  position: 'absolute',
                  top: 7,
                  right: 7,
                  width: 8,
                  height: 8,
                  borderRadius: '50%',
                  backgroundColor: 'var(--color-secondary)'
                }}
              />
            )}
          </button>

          {showNotifications && (
            <div
              style={{
                position: 'absolute',
                top: 46,
                right: 0,
                width: 300,
                backgroundColor: 'var(--bg-card)',
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-lg)',
                boxShadow: 'var(--shadow-xl)',
                padding: '12px 0',
                zIndex: 50,
                animation: 'scaleUp 0.15s ease-out'
              }}
            >
              <div
                style={{
                  padding: '4px 16px 10px',
                  borderBottom: '1px solid var(--border-color)',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}
              >
                <span style={{ fontWeight: 700, fontSize: '0.9rem' }}>Notifications</span>
                <span className="badge badge-medium">{pendingCount} pending</span>
              </div>
              <div style={{ maxHeight: 240, overflowY: 'auto' }}>
                {recentTasks.map((t) => (
                  <div
                    key={t.id}
                    style={{
                      padding: '10px 16px',
                      display: 'flex',
                      alignItems: 'flex-start',
                      gap: 10,
                      borderBottom: '1px solid var(--border-subtle)',
                      fontSize: '0.85rem'
                    }}
                  >
                    {t.status === 'Completed' ? (
                      <CheckCircle2 size={16} color="var(--color-success)" style={{ marginTop: 2 }} />
                    ) : (
                      <Clock size={16} color="var(--color-warning)" style={{ marginTop: 2 }} />
                    )}
                    <div>
                      <div style={{ fontWeight: 600, color: 'var(--text-main)' }}>{t.title}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                        Priority: {t.priority} • Due {t.dueDate}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div style={{ padding: '8px 16px 0', textAlign: 'center' }}>
                <Link
                  to="/tasks"
                  onClick={() => setShowNotifications(false)}
                  style={{ fontSize: '0.8rem', color: 'var(--color-secondary)', fontWeight: 600 }}
                >
                  View All Tasks →
                </Link>
              </div>
            </div>
          )}
        </div>

        {/* User Avatar & Dropdown */}
        <div style={{ position: 'relative' }}>
          <button
            type="button"
            onClick={() => setShowUserMenu(!showUserMenu)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 10,
              padding: '4px 8px',
              borderRadius: 'var(--radius-full)',
              cursor: 'pointer',
              border: '1px solid transparent'
            }}
            aria-label="User menu"
          >
            <div
              style={{
                width: 34,
                height: 34,
                borderRadius: '50%',
                backgroundColor: 'var(--color-primary)',
                color: '#FFF',
                overflow: 'hidden',
                border: '2px solid var(--color-secondary)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontWeight: 700,
                fontSize: '0.85rem'
              }}
            >
              {currentUser?.avatar ? (
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name || 'User'}
                  style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                  onError={(e) => {
                    e.target.style.display = 'none';
                  }}
                />
              ) : (
                (currentUser?.name || 'U').charAt(0).toUpperCase()
              )}
            </div>
            <span
              className="navbar-user-name"
              style={{
                fontWeight: 600,
                fontSize: '0.88rem',
                color: 'var(--text-main)',
                maxWidth: 110,
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                textOverflow: 'ellipsis'
              }}
            >
              {currentUser?.name?.split(' ')[0] || 'User'}
            </span>
          </button>

          {showUserMenu && (
            <div
              style={{
                position: 'absolute',
                top: 46,
                right: 0,
                width: 210,
                backgroundColor: 'var(--bg-card)',
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-lg)',
                boxShadow: 'var(--shadow-xl)',
                padding: '8px 0',
                zIndex: 50,
                animation: 'scaleUp 0.15s ease-out'
              }}
            >
              <div style={{ padding: '8px 16px 10px', borderBottom: '1px solid var(--border-color)' }}>
                <div style={{ fontWeight: 700, fontSize: '0.9rem' }}>{currentUser?.name || 'QuickTask User'}</div>
                <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{currentUser?.email}</div>
              </div>

              <Link
                to="/profile"
                onClick={() => setShowUserMenu(false)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 10,
                  padding: '10px 16px',
                  fontSize: '0.88rem',
                  color: 'var(--text-main)',
                  transition: 'background var(--transition-fast)'
                }}
                onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = 'var(--bg-subtle)')}
                onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
              >
                <User size={16} color="var(--text-muted)" />
                My Profile
              </Link>

              <button
                type="button"
                onClick={handleLogout}
                style={{
                  width: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 10,
                  padding: '10px 16px',
                  fontSize: '0.88rem',
                  color: 'var(--color-danger)',
                  textAlign: 'left',
                  borderTop: '1px solid var(--border-subtle)',
                  marginTop: 4
                }}
                onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = 'var(--color-danger-bg)')}
                onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
              >
                <LogOut size={16} />
                Log Out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
