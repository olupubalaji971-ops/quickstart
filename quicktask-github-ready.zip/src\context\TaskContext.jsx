import React, { createContext, useContext, useState, useEffect } from 'react';
import { getStoredItem, setStoredItem } from '../utils/storage';
import { INITIAL_TASKS } from '../utils/initialData';
import { useToast } from './ToastContext';
import confetti from 'canvas-confetti';

const TaskContext = createContext();

export const TaskProvider = ({ children }) => {
  const { showToast } = useToast();

  const [tasks, setTasks] = useState(() => {
    return getStoredItem('quicktask_tasks', INITIAL_TASKS);
  });

  // Keep localStorage synced
  useEffect(() => {
    setStoredItem('quicktask_tasks', tasks);
  }, [tasks]);

  // Statistics calculation
  const stats = {
    total: tasks.length,
    completed: tasks.filter((t) => t.status === 'Completed').length,
    pending: tasks.filter((t) => t.status === 'Pending').length,
    highPriority: tasks.filter((t) => t.priority === 'High' && t.status === 'Pending').length
  };

  // Add Task
  const addTask = (taskData) => {
    const newTask = {
      id: 'task_' + Date.now(),
      title: taskData.title.trim(),
      description: taskData.description?.trim() || '',
      priority: taskData.priority || 'Medium',
      dueDate: taskData.dueDate || new Date().toISOString().split('T')[0],
      category: taskData.category || 'Work',
      status: 'Pending',
      createdAt: new Date().toISOString(),
      completedAt: null
    };

    setTasks((prev) => [newTask, ...prev]);
    showToast(`Task "${newTask.title}" created successfully!`, 'success');
    return newTask;
  };

  // Update Task
  const updateTask = (id, updatedData) => {
    setTasks((prev) =>
      prev.map((task) => {
        if (task.id === id) {
          return {
            ...task,
            ...updatedData,
            title: updatedData.title ? updatedData.title.trim() : task.title,
            description: updatedData.description !== undefined ? updatedData.description.trim() : task.description
          };
        }
        return task;
      })
    );
    showToast('Task updated successfully!', 'success');
  };

  // Delete Task
  const deleteTask = (id) => {
    const taskToDelete = tasks.find((t) => t.id === id);
    setTasks((prev) => prev.filter((task) => task.id !== id));
    showToast(`Task "${taskToDelete ? taskToDelete.title : 'Selected task'}" deleted.`, 'info');
  };

  // Toggle Complete / Reopen Task
  const toggleComplete = (id) => {
    setTasks((prev) =>
      prev.map((task) => {
        if (task.id === id) {
          const isCompleting = task.status !== 'Completed';
          if (isCompleting) {
            // Trigger confetti burst!
            try {
              confetti({
                particleCount: 50,
                spread: 60,
                origin: { y: 0.7 }
              });
            } catch (e) {
              // Ignore if canvas confetti isn't available
            }
            showToast(`Task "${task.title}" completed! Great job 🎉`, 'success');
          } else {
            showToast(`Task "${task.title}" reopened to pending.`, 'info');
          }

          return {
            ...task,
            status: isCompleting ? 'Completed' : 'Pending',
            completedAt: isCompleting ? new Date().toISOString() : null
          };
        }
        return task;
      })
    );
  };

  // Reset to sample data
  const resetToSampleData = () => {
    setTasks(INITIAL_TASKS);
    showToast('Sample tasks restored successfully!', 'info');
  };

  return (
    <TaskContext.Provider
      value={{
        tasks,
        stats,
        addTask,
        updateTask,
        deleteTask,
        toggleComplete,
        resetToSampleData
      }}
    >
      {children}
    </TaskContext.Provider>
  );
};

export const useTasks = () => {
  const context = useContext(TaskContext);
  if (!context) {
    throw new Error('useTasks must be used within a TaskProvider');
  }
  return context;
};
